﻿# Face-Recognition-Attendance-System

This repository contains the code and resources for a facial recognition system. The system is designed to identify and authenticate individuals based on facial features using deep learning techniques.
![Screenshot 2024-04-09 065333](https://github.com/francis-njenga/Face-Recognition-Attendance-System/assets/81665629/307737d0-da1f-435a-aa08-af78ad529e73)
![Screenshot 2024-04-09 055007](https://github.com/francis-njenga/Face-Recognition-Attendance-System/assets/81665629/998af475-3b49-4ef3-82bf-a729d1888128)
![Screenshot 2024-04-09 054940](https://github.com/francis-njenga/Face-Recognition-Attendance-System/assets/81665629/24bbc593-dd20-4f74-836e-ce2e265a2d9c)
![Screenshot 2024-04-07 113344](https://github.com/francis-njenga/Face-Recognition-Attendance-System/assets/81665629/63f24603-a93b-4d7b-b362-4611018e4400)
![Screenshot 2024-04-07 113315](https://github.com/francis-njenga/Face-Recognition-Attendance-System/assets/81665629/90cff5f8-7af7-46ed-91fb-040bc7f2cde4)


